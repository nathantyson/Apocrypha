using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreBarrierComm : MonoBehaviour
{
    public int requiredScore = 100;

    BoxCollider2D barrier;
    SpriteRenderer barrierSprite;
    GameObject manager;
    GameManager getScore;


    void Start()
    {
        barrier = GetComponent<BoxCollider2D>();
        barrierSprite = GetComponent<SpriteRenderer>();
        manager = GameObject.FindWithTag("GameController");
    }


    void Update()
    {
        getScore = manager.GetComponent<GameManager>();
        int scoreamount = getScore.score;
        if(scoreamount >= requiredScore)
        {
            barrier.enabled = false;
            barrierSprite.enabled = false;
        }
    }
}
